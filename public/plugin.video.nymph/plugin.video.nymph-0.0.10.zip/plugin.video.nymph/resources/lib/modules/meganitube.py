# coding=utf-8
import urllib, urllib2, re, xbmcplugin, xbmcgui, xbmc, xbmcaddon, HTMLParser, random, sys
from xbmcgui import ListItem

from ..base import utils
import BeautifulSoup

_base = 'http://www.meganitube.com'
_addon_id = 'plugin.video.nymph'
_selfAddon = xbmcaddon.Addon(id=_addon_id)
_addonfolder = _selfAddon.getAddonInfo('path')
_mediaPath = _addonfolder + '/resources/media'
_meganitubeLogo = _mediaPath + "/logos/meganitube.png"
_folderImage = _mediaPath + "/animegirl_1.jpg"
_searchImage = _mediaPath + "/animegirl_2.jpeg"
h = HTMLParser.HTMLParser()


class menu:
    def __init__(self):
        self.open()

    def open(self):
        utils.core().addDir('none', 'Menu Principal', '-', 0, _folderImage)
        utils.core().addDir('none', 'Ultimos', _base, 14, _meganitubeLogo)
        utils.core().addDir('none', 'Gêneros', _base, 10, _meganitubeLogo)
        #utils.core().addDir('none', 'Pesquisa', _base, 15, _searchImage)
        self.endDirectory()

    def endDirectory(self, cacheToDisc=True):
        utils.core().directory(int(sys.argv[1]), cacheToDisc=cacheToDisc)


def getGeneros(url):
    link = utils.core().openURL(url)
    soup = BeautifulSoup.BeautifulSoup(link)
    generosList = soup.find("ul", {"class": "dropdown-menu"}).findAll('li')
    g = []
    for generos in generosList:
        try:
            titTemp = generos.a.text.encode('utf-8', 'ignore')
            urlTemp = generos.a["href"].encode('utf-8', 'ignore')
            temp = [urlTemp, titTemp]
            g.append(temp)
        except:
            pass
    total = len(g)
    utils.core().addDir('none', 'Menu Principal', '-', 0, _folderImage)
    for url2, titulo in g:
        try:
            utils.core().addDir('none', titulo, url2, 11, _meganitubeLogo)
        except:
            pass
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmc.executebuiltin('Container.SetViewMode(515)')
    utils.core().directory(int(sys.argv[1]), cacheToDisc=True)


def getCategorias(url):
    link = utils.core().openURL(url)
    soup = BeautifulSoup.BeautifulSoup(link)
    animesCat = soup.find("div", {"class": "panel-body"})
    categorias = animesCat.findAll("div", {"class": "serie_list_item2"})
    a = []
    for categoria in categorias:
        try:
            urlTemp = categoria.a["href"].encode('utf-8', 'ignore')
            titTemp = categoria.a.img["alt"].encode('utf-8', 'ignore')
            imgTemp = categoria.a.img["src"]
            plotTemp = categoria.findAll("div", {"class": "sdline"})[1].text
            temp = [urlTemp, titTemp, imgTemp, plotTemp]
            a.append(temp)
        except:
            pass
    total = len(a)
    utils.core().addDir('none', 'Menu Principal', '-', 0, _folderImage)

    for url2, titulo, img, plot in a:
        try:
            titulo = utils.core().cleanHtml(titulo)
            utils.core().addDir('1', titulo, url2, 12, img, True, total, h.unescape(plot))
        except:
            pass

    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmc.executebuiltin('Container.SetViewMode(515)')
    utils.core().directory(int(sys.argv[1]), cacheToDisc=True)


def getEpisodios(url, iconimage):
    link = utils.core().openURL(url)
    soup = BeautifulSoup.BeautifulSoup(link)
    animeEps = soup.find("div", {"class": "list-group lista-episodios"})
    episodios = animeEps.findAll("a")
    e = []
    for episodio in episodios:
        try:
            titTemp = episodio.text.encode('utf-8', 'ignore')
            urlTemp = episodio["href"].encode('utf-8', 'ignore')
            temp = [titTemp, urlTemp]
            e.append(temp)
        except:
            pass
    total = len(e)
    for titulo, url2 in e:
        titulo = h.unescape(titulo).encode('utf-8', 'ignore')
        utils.core().addDir('1', titulo, url2, 13, iconimage, False, total, titulo)

    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmc.executebuiltin('Container.SetViewMode(515)')
    utils.core().directory(int(sys.argv[1]), cacheToDisc=True)


def doPlay(url, name, iconimage):
    link = utils.core().openURL(url)
    soup = BeautifulSoup.BeautifulSoup(link)
    iframe = soup.findAll('iframe')[1]
    linkIframe = utils.core().openURL(iframe['src'])
    soupIframe = BeautifulSoup.BeautifulSoup(linkIframe)
    iframe2 = soupIframe.findAll('iframe')[0]
    linkIframe2 = utils.core().openURL(iframe2['src'])
    soupIframe2 = BeautifulSoup.BeautifulSoup(linkIframe2)
    videos = soupIframe2.find('source')
    playlist = xbmc.PlayList(1)
    playlist.clear()
    listitem = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    listitem.setInfo("Video", {"Title": name})
    listitem.setProperty('mimetype', 'video/mp4')
    listitem.setProperty('IsPlayable', 'true')
    playlist.add(videos["src"].encode('ascii', 'ignore'), listitem)
    xbmcPlayer = xbmc.Player()
    xbmcPlayer.play(playlist)


def lastAnimes(url):
    link = utils.core().openURL(url)
    soup = BeautifulSoup.BeautifulSoup(link)
    animesCat = soup.find("div", {"class": "tabs-container"})
    categorias = animesCat.findAll("div", {"class": "boxDestakTImg"})
    a = []
    for categoria in categorias:
        try:
            urlTemp = categoria.a["href"]
            titTemp = categoria.a.img["alt"].encode('utf-8', 'ignore')
            imgTemp = categoria.a.img["src"]
            plotTemp = categoria.a["title"]
            temp = [urlTemp, titTemp, imgTemp, plotTemp]
            a.append(temp)
        except:
            pass

    total = len(a)
    utils.core().addDir('none', 'Menu Principal', '-', 0, _folderImage)

    for url2, titulo, img, plot in a:
        try:
            titulo = utils.core().cleanHtml(titulo)
            utils.core().addDir('1', titulo, _base + "/" + url2, 13, img, True, total, plot)
        except:
            pass

    pages = soup.find('div', {"class": "pagenav clearfix"})
    if pages is not None:
        pages = pages.findAll('a')
        for prox_pagina in pages:
            if prox_pagina.text != '&raquo;':
                utils.core().addDir('none', 'Página ' + prox_pagina.text.encode('ascii', 'ignore') + ' >>',
                                    prox_pagina['href'], 21, '')

    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmc.executebuiltin('Container.SetViewMode(515)')
    utils.core().directory(int(sys.argv[1]), cacheToDisc=True)


def doPesquisa():
    keyb = xbmc.Keyboard('', 'Pesquisar...')
    keyb.doModal()

    if (keyb.isConfirmed()):
        search = keyb.getText()
        busca = urllib.quote(search)
        url = _base + '/?s=' + str(busca) + '&cat=780'
        getCategorias(url)
