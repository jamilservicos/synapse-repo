# -*- coding: UTF-8 -*-
# By juliojamil - 07/05/16
#########################################################################
#import xbmc, xbmcplugin, xbmcgui, xbmcaddon, sys
#from resources.lib.base import utils
#from resources.lib.base import menu
from resources.lib.base import modes

#addon_handle = int(sys.argv[1])

#utils.core().log('teste')
#menu.menu()
modes
##xbmc.log('BASE URL: %s' %  xbmcaddon.Addon(), xbmc.LOGERROR)

#xbmcplugin.endOfDirectory(addon_handle)