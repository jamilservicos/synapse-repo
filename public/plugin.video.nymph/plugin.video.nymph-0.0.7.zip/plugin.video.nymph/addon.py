# -*- coding: UTF-8 -*-
# By juliojamil - 07/05/16
#########################################################################
from resources.lib.base import modes

modes
