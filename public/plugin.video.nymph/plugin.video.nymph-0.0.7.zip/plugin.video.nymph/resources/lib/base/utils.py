# -*- coding: UTF-8 -*-
# By juliojamil - 07/05/16
#########################################################################
import urllib, urllib2, re
import xbmc, xbmcplugin, xbmcgui, xbmcaddon
import HTMLParser,sys

from xbmcgui import ListItem

addItem = xbmcplugin.addDirectoryItem
directory = xbmcplugin.endOfDirectory

############################################################################################################
#                                               Functions                                                #
############################################################################################################
class core:
	def __init__(self):
		self.logerror = xbmc.LOGERROR
		self.lognotice = xbmc.LOGNOTICE
		self.addon_id = 'plugin.video.nymph'
		self.selfAddon = xbmcaddon.Addon(id=self.addon_id)
		self.addonfolder = self.selfAddon.getAddonInfo('path')
		self.artfolder = self.addonfolder + '/resources/media'
		self.fanart = self.artfolder + '/animegirl_1.jpg'
		
	def log(self, msg):
		try:
			if isinstance(msg, unicode):
				msg = '%s (ENCODED)' % (msg.encode('utf-8'))
			
			xbmc.log('[Nymph] Notice: %s' % (msg), self.lognotice)
				
		except Exception as e:
			try:
				xbmc.log('[Nymph] Logging Failure: %s , Notice: %s' % (e, msg), self.logerror)				
			except: pass #just give up
			
	def addDir(self,flevel,name,url,mode,iconimage,pasta=True,total=1,plot=''):
		if not iconimage:
			iconimage = "DefaultFolder.png"
			fanart = self.fanart
		else:
			if flevel == "none" or len(flevel)<1:
				fanart = self.fanart
			else:
				fanart = iconimage
		
		#if url == "-":
			#url = sys.argv[0]
			
		#xbmc.log('LEVEL: %s - NAME: %s - URL: %s' %  (flevel,name,url), xbmc.LOGERROR)
		
		u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
		liz=xbmcgui.ListItem(name, iconimage, iconimage)
		liz.setProperty('fanart_image', fanart)
		liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": plot})
		addItem(int(sys.argv[1]),u,liz,pasta,total)

	def openURL(self, url):
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
		req.add_header('Accept-Encoding', 'utf-8')
		response = urllib2.urlopen(req)
		link=response.read()
		response.close()
		return link
		
	def cleanHtml(self, dirty):
		clean = re.sub('&quot;', '\"', dirty)
		clean = re.sub('&#039;', '\'', clean)
		clean = re.sub('&#215;', 'x', clean)
		clean = re.sub('&#038;', '&', clean)
		clean = re.sub('&#8216;', '\'', clean)
		clean = re.sub('&#8217;', '\'', clean)
		clean = re.sub('&#8211;', '-', clean)
		clean = re.sub('&#8220;', '\"', clean)
		clean = re.sub('&#8221;', '\"', clean)
		clean = re.sub('&#8212;', '-', clean)
		clean = re.sub('&amp;', '&', clean)
		clean = re.sub("`", '', clean)
		clean = re.sub('<em>', '[I]', clean)
		clean = re.sub('</em>', '[/I]', clean)
		return clean
		
		
		
def menuroot():
	xbmc.executebuiltin("XBMC.Container.Update(%s,replace)" % sys.argv[0])
	xbmc.executebuiltin("XBMC.Container.Refresh")
	
def fechar():
	xbmc.executebuiltin("XBMC.ActivateWindow(Home)")
