#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# By juliojamil - 07/05/16
#########################################################################
import random, sys
from resources.lib.base import utils

class menu:
	def __init__(self):
		self.animesorionBase = 'http://www.animesorion.net'
		self.meganitubeBase = 'http://www.meganitube.com'
		self.open()
		
	def open(self):
		utils.core().addDir('none', 'Anitube','-',2,'http://i.imgur.com/yK01cW2.png')	
		utils.core().addDir('none', 'AnimesOrion','-',1,'https://2.bp.blogspot.com/-lSTjYuDBiAQ/VvST8Z7z2OI/AAAAAAAAGPY/c8yAE675bLEMYI-OMwtauCiXeu1yZPZaw/s1600/fundososvideos.jpg')	
		utils.core().addDir('none', 'Fechar','-',1000,'')
		self.endDirectory()

	def endDirectory(self, cacheToDisc=True):
		utils.directory(int(sys.argv[1]), cacheToDisc=cacheToDisc)
		
def menu_root():
	utils.menuroot()
	
def fechar():
	utils.fechar()
