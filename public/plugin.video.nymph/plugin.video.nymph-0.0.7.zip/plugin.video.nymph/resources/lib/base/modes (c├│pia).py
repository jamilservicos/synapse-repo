#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# By juliojamil - 07/05/16
#########################################################################
import urllib, urllib2, re
import xbmc, xbmcplugin, xbmcgui, xbmcaddon
import HTMLParser,sys

from resources.lib.base import utils
from resources.lib.base import menu
from resources.lib.modules import anitube

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

params = get_params()
url = None
name = None
mode = None
iconimage = None

try:
	url = urllib.unquote_plus(params["url"])
except: pass

try:
	name = urllib.unquote_plus(params["name"])
except: pass

try:
	mode = int(params["mode"])
except:  pass

try:
	iconimage=urllib.unquote_plus(params["iconimage"])
except: pass

###############################################################################################################
#                                                   MODOS                                                     #
###############################################################################################################
if mode == None		: 	menu.menu()
elif mode == 0		:	menu.menu_root()
elif mode == 1000	:	menu.fechar()
elif mode == 1		:	anitube.menu() #menu anitube
#elif mode == 1		:	utils.core().log('menu anitube') #menu anitube
elif mode == 10		:	anitube.getCategorias(url) #categorias de animes
#elif mode == 10	:	utils.core().log('categorias de animes') #categorias de animes
elif mode == 11		:	anitube.doPesquisa() #pesquisa de animes
#elif mode == 11	:	utils.core().log('pesquisa de animes') #pesquisa de animes
elif mode == 12		:	anitube.getEpisodios(url) #episodios de animes
#elif mode == 12	:	utils.core().log('episodios de animes') #episodios de animes
elif mode == 13		:	anitube.doPlay(url, name, iconimage) #player de animes
#elif mode == 13	:	utils.core().log('player de animes') #player de animes
elif mode == 14		:	animesorion.getCategorias2(url) #categorias de animes

