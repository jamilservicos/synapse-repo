#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# By juliojamil - 06/09/16
#########################################################################
import urllib, urllib2, re
import xbmc, xbmcplugin, xbmcgui, xbmcaddon
import HTMLParser,sys

from resources.lib.base import utils
from resources.lib.base import menu
from resources.lib.modules import animesorion
from resources.lib.modules import meganitube


def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

params = get_params()
url = None
name = None
mode = None
iconimage = None

try:
	url = urllib.unquote_plus(params["url"])
except: pass

try:
	name = urllib.unquote_plus(params["name"])
except: pass

try:
	mode = int(params["mode"])
except:  pass

try:
	iconimage=urllib.unquote_plus(params["iconimage"])
except: pass

###############################################################################################################
#                                                   MODOS                                                     #
###############################################################################################################
if mode == None		: 	menu.menu()
elif mode == 0		:	menu.menu_root()
elif mode == 1000	:	menu.fechar()
elif mode == 1		:	animesorion.menu() #menu anitube
elif mode == 10		:	animesorion.getGeneros(url) #generos de animes
elif mode == 11		:	animesorion.getCategorias(url) #categorias de animes
elif mode == 12		:	animesorion.getEpisodios(url, iconimage) #episodios de animes
elif mode == 13		:	animesorion.doPlay(url, name, iconimage) #player de animes
elif mode == 14		:	animesorion.doPesquisa() #pesquisa de animes
#elif mode == 2		:	utils.core().log('menu meganitube') #menu anitube
elif mode == 2		:	meganitube.menu() #menu anitube
elif mode == 20		:	meganitube.getGeneros(url) #generos anitube
elif mode == 21		:	meganitube.getCategorias(url) #categorias anitube