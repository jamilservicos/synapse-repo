# -*- coding: UTF-8 -*-
# By juliojamil - 06/09/16
#########################################################################
import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,HTMLParser,random, sys
from xbmcgui import ListItem

from resources.lib.base import utils
from resources.lib.modules import BeautifulSoup

base = 'http://www.animesorion.net'

class menu:
	def __init__(self):
		self.open()
		
	def open(self):
		utils.core().addDir('none', 'Legendados',base + '/3660',10,'https://2.bp.blogspot.com/-lSTjYuDBiAQ/VvST8Z7z2OI/AAAAAAAAGPY/c8yAE675bLEMYI-OMwtauCiXeu1yZPZaw/s1600/fundososvideos.jpg')
		utils.core().addDir('none', 'Dublados',base + '/animes-dublados',11,'https://2.bp.blogspot.com/-lSTjYuDBiAQ/VvST8Z7z2OI/AAAAAAAAGPY/c8yAE675bLEMYI-OMwtauCiXeu1yZPZaw/s1600/fundososvideos.jpg')
		#utils.core().addDir('none', 'Pesquisa','-',14,'https://2.bp.blogspot.com/-lSTjYuDBiAQ/VvST8Z7z2OI/AAAAAAAAGPY/c8yAE675bLEMYI-OMwtauCiXeu1yZPZaw/s1600/fundososvideos.jpg')
		self.endDirectory()

	def endDirectory(self, cacheToDisc=True):
		utils.directory(int(sys.argv[1]), cacheToDisc=cacheToDisc)

###################################################		
def getGeneros(url):
	link = utils.core().openURL(url)
	#link = unicode(link, 'ascii', errors='ignore')	
	soup = BeautifulSoup.BeautifulSoup(link)
	categorias = soup.find("select", { "class" : "box2" }).findAll('option')
	a = []
	for categoria in categorias:
		if categoria.text.encode('ascii', 'ignore') != "GNEROS:":
			urlTemp = categoria['value'].encode('ascii', 'ignore')
			titTemp  = categoria.text.encode('utf-8', 'ignore')
			temp = [urlTemp, titTemp] 
			a.append(temp)			
	total = len(a)
	utils.core().addDir('none', 'Menu Principal','-',0,'')
	for url2, titulo in a:
		utils.core().addDir('none', titulo,url2,11,'https://2.bp.blogspot.com/-lSTjYuDBiAQ/VvST8Z7z2OI/AAAAAAAAGPY/c8yAE675bLEMYI-OMwtauCiXeu1yZPZaw/s1600/fundososvideos.jpg')
	
	xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	xbmc.executebuiltin('Container.SetViewMode(515)')
	utils.directory(int(sys.argv[1]), cacheToDisc=True)

	
###################################################		
def getCategorias(url):
	link = utils.core().openURL(url)
#	link = unicode(link, 'ascii', errors='ignore')	
	soup = BeautifulSoup.BeautifulSoup(link)
	categorias = soup.findAll("div", { "class" : "telinhasimg" })
	a = []
	for categoria in categorias:
		try:
			urlTemp  = categoria.a["href"]
			titTemp  = categoria.a.img["alt"].encode('utf-8', 'ignore')
			imgTemp  = categoria.a.img["src"]
			plotTemp = categoria.a["title"]
			temp = [urlTemp, titTemp, imgTemp, plotTemp] 			
			a.append(temp)	
		except:
			pass

	total = len(a)
	utils.core().addDir('none', 'Menu Principal','-',0,'')
	
	for url2, titulo, img, plot in a:
		try:
			titulo = utils.core().cleanHtml(titulo)
			utils.core().addDir('1',titulo,url2,12,img,True,total,plot)	
		except:
			pass
		
	pages = soup.find('div',{ "class" : "pagenav clearfix" })
	if pages is not None:
		pages= pages.findAll('a')
		for prox_pagina in pages:
			if prox_pagina.text != '&raquo;':
				utils.core().addDir('none','Página '+ prox_pagina.text.encode('ascii', 'ignore') +' >>',prox_pagina['href'],11,'')
		
	xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	xbmc.executebuiltin('Container.SetViewMode(515)')
	utils.directory(int(sys.argv[1]), cacheToDisc=True)
	
###################################################		
def getEpisodios(url, iconimage):
	link = utils.core().openURL(url)
#	link = unicode(link, 'ascii', errors='ignore')
	soup = BeautifulSoup.BeautifulSoup(link)
	#imgAnime = soup.find("div", { "id" : "content", "class" : "list-post"  }).findAll('img')[0]
	#episodios = soup.find("div", { "id" : "listadeepisodios" }).findAll('li')

	e = []
	for ep in soup.findAll('div',attrs={ "id" : "listadeepisodios" }):
		#utils.core().log(ep.findAll('li'))
		episodios = ep.findAll('li')
		for episodio in episodios:
			try:
				titTemp = episodio.a.text.encode('utf-8', 'ignore')
				urlTemp = episodio.a["href"]
				temp = [titTemp, urlTemp]
				e.append(temp)
			except:
				pass			
		
	total = len(e)
	for titulo, url2 in e:
		titulo = utils.core().cleanHtml(titulo)
		utils.core().addDir('1', titulo, url2.encode('ascii', 'ignore'), 13, iconimage, False, total, titulo)
	
	xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	xbmc.executebuiltin('Container.SetViewMode(515)')
	utils.directory(int(sys.argv[1]), cacheToDisc=True)
	
###################################################		
def doPlay(url, name, iconimage):
	link = utils.core().openURL(url)
	link = unicode(link, 'ascii', errors='ignore')
	soup = BeautifulSoup.BeautifulSoup(link)
	videos = soup.find('source')
	playlist = xbmc.PlayList(1)
	playlist.clear()	
	listitem = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	listitem.setInfo("Video", {"Title":name})
	listitem.setProperty('mimetype', 'video/mp4')
	listitem.setProperty('IsPlayable', 'true')
	playlist.add(videos["src"].encode('ascii', 'ignore'),listitem)	
	xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
	xbmcPlayer.play(playlist)
	
###################################################		
def doPesquisa():
	keyb = xbmc.Keyboard('', 'Pesquisar...')
	keyb.doModal()

	if (keyb.isConfirmed()):
		search = keyb.getText()
		busca = urllib.quote(search)
		url = base + '/?s=' + str(busca)
		getCategorias(url)
