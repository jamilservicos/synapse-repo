# -*- coding: UTF-8 -*-
# By juliojamil - 07/05/16
#########################################################################
import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,HTMLParser,random, sys
from xbmcgui import ListItem

from resources.lib.base import utils
from resources.lib.modules import BeautifulSoup

base = 'http://www.meganitube.com/'

class menu:
	def __init__(self):
		self.open()
		
	def open(self):
		utils.core().addDir('none', 'Ultimos','-','-','-')
		utils.core().addDir('none', 'Gêneros',base,'20','-')
		utils.core().addDir('none', 'Pesquisa','-','-','-')
		self.endDirectory()

	def endDirectory(self, cacheToDisc=True):
		utils.directory(int(sys.argv[1]), cacheToDisc=cacheToDisc)

###################################################		
def getGeneros(url):
	link = utils.core().openURL(url)
	link = unicode(link, 'ascii', errors='ignore')
	soup = BeautifulSoup.BeautifulSoup(link)
	generosList = soup.find("ul", { "class" : "dropdown-menu" }).findAll('li')
	
	g = []
	for generos in generosList:
		try:
			titTemp = generos.a.text
			urlTemp = generos.a["href"]
			temp = [urlTemp, titTemp]
			g.append(temp)
		except:
				pass
	
	total = len(g)
	utils.core().addDir('none', 'Menu Principal','-',0,'')
	for url2, titulo in g:
		try:
			utils.core().addDir('none', titulo,url2,21,'http://i.imgur.com/yK01cW2.png')
		except:
				pass

	xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	xbmc.executebuiltin('Container.SetViewMode(515)')
	utils.directory(int(sys.argv[1]), cacheToDisc=True)
	
###################################################		
def getCategorias(url):
	
	xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	xbmc.executebuiltin('Container.SetViewMode(515)')
	utils.directory(int(sys.argv[1]), cacheToDisc=True)