# -*- coding: UTF-8 -*-
# By juliojamil - 07/05/16
#########################################################################
import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmc,xbmcaddon,HTMLParser,random, sys
from xbmcgui import ListItem

from resources.lib.base import utils
from resources.lib.modules import BeautifulSoup

base = 'http://www.anitube.info'

class menu:
	def __init__(self):
		self.open()
		
	def open(self):
		utils.core().addDir('none', 'Categorias',base + '/categories',10,'http://www.anitube.info/templates/frontend/bright-blue/img/logo.png')
		utils.core().addDir('none', 'Pesquisa','-',11,'http://www.anitube.info/templates/frontend/bright-blue/img/logo.png')
		self.endDirectory()

	def endDirectory(self, cacheToDisc=True):
		utils.directory(int(sys.argv[1]), cacheToDisc=cacheToDisc)
		

###################################################		
def getCategorias(url):
	link = utils.core().openURL(url)
	link = unicode(link, 'ascii', errors='ignore')	
	soup = BeautifulSoup.BeautifulSoup(link)
#	categorias = soup.findAll("div", { "class" : "col-sm-6 col-md-4 col-lg-4 m-b-20" })
	categorias = soup.findAll("div", { "class" : "col-lg-3 col-md-4 col-sm-6 col-xs-12" })
	a = []	
	for categoria in categorias:
			urlTemp  = categoria.a["href"].replace('/videos/', base + '/videos/')
#			titTemp  = categoria.a.img["alt"].replace(' category','').encode('ascii', 'ignore')
			titTemp  = categoria.a.img["alt"].encode('ascii', 'ignore')
			imgTemp  = categoria.a.img["src"]
#			bagdeTemp  = categoria.span.text.replace('Total', 'Total de episodios:').encode('ascii', 'ignore')
#			utils.core().log('proxima: ' + str(bagdeTemp))
#			plotTemp = categoria.a["href"].replace('/videos/', '').replace('-', ' ').encode('ascii', 'ignore') + '. ' + bagdeTemp
			plotTemp = categoria.a["href"].replace('/videos/', '').replace('-', ' ').encode('ascii', 'ignore') + '. '
			temp = [urlTemp, titTemp, imgTemp, plotTemp] 			
			a.append(temp)			
	total = len(a)
	utils.core().addDir('none', 'Menu Principal','-',0,'')
	for url2, titulo, img, plot in a:
		titulo = utils.core().cleanHtml(titulo)
		utils.core().addDir('1',titulo,url2,12,img,True,total,plot)		
	pages = soup.find('ul',{ "class" : "pagination" }).findAll('a')
	for prox_pagina in pages:
		if prox_pagina.text == "Avanar":
			utils.core().addDir('none','Próxima Página >>', base + prox_pagina['href'], 10, '')
	xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	xbmc.executebuiltin('Container.SetViewMode(515)')
	utils.directory(int(sys.argv[1]), cacheToDisc=True)

def getEpisodios(url):
	link = utils.core().openURL(url)
	link = unicode(link, 'ascii', errors='ignore')
	soup = BeautifulSoup.BeautifulSoup(link)
	episodios = soup.findAll("div", { "class" : "well well-sm" })	
	e = []	
	for episodio in episodios:
		try:
			titTemp = episodio.a.img["alt"].encode('ascii', 'ignore')
			urlTemp = episodio.a["href"]
			imgTemp = episodio.a.img['src']
			temp = [titTemp, urlTemp ,imgTemp, titTemp] 
			e.append(temp)
		except:
			pass			
	total = len(e)
	for titulo, url2, img, plot in e:
		titulo = utils.core().cleanHtml(titulo)
		utils.core().addDir('1',titulo, base + url2, 13, img, False, total, plot)		
	try:
		pages = soup.find('ul',{ "class" : "pagination" }).findAll('a')		
		for prox_pagina in pages:
			if prox_pagina.text == '&raquo;':
					utils.core().addDir('none','Próxima Página >>',prox_pagina['href'],12,'')
					#utils.core().log('proxima: ' + prox_pagina['href'])
	except:
			pass
			
	xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	xbmc.executebuiltin('Container.SetViewMode(515)')
	utils.directory(int(sys.argv[1]), cacheToDisc=True)
	
def doPlay(url, name, iconimage):
	link = utils.core().openURL(url)
#	jwpKEY = re.findall(r'vid=(.*?)"><\/script>',link)[0]
#<source src="http://cloud2.anitube.info/cdn/sd/6787.mp4/manifest.mpd?wmsAuthSign=c2VydmVyX3RpbWU9Ny8yLzIwMTYgMTE6NDA6MTUgUE0maGFzaF92YWx1ZT1QYkQzU1UyS3NGVkR0TklINU1WYzF3PT0mdmFsaWRtaW51dGVzPTU2MA==" type="video/mp4">
	jwpKEY = re.findall(r'<source src="(.*?)" type="video/mp4"/>',link)[0]
#	utils.core().log('teste:' + jwpKEY.replace("sd", "hd"))
	playlist = xbmc.PlayList(1)
	playlist.clear()	
	listitem = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	listitem.setInfo("Video", {"Title":name})
	listitem.setProperty('mimetype', 'video/mp4')
	listitem.setProperty('IsPlayable', 'true')
	#playlist.add(str(urlx).replace("['", "").replace("']", "") + '.mp4',listitem)
	playlist.add(str(jwpKEY),listitem)	
	xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
	xbmcPlayer.play(playlist)
	
	
def doPesquisa():
	keyb = xbmc.Keyboard('', 'Pesquisar...')
	keyb.doModal()

	if (keyb.isConfirmed()):
		search = keyb.getText()
		busca = urllib.quote(search)
		url = base + '/search/videos?search_query=' + str(busca)
		getEpisodios(url)
		#utils.core().log('url: ' + url)
		