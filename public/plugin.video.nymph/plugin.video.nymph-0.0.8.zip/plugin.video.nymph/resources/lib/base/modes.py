# coding=utf-8
import xbmc, urllib, sys
from . import utils, menu
from ..modules import meganitube, animesorion, vfohd


def get_params():
    param = []
    try:
        paramstring = sys.argv[2]
        if len(paramstring) >= 2:
            params = sys.argv[2]
            cleanedparams = params.replace('?', '')
            if (params[len(params) - 1] == '/'):
                params = params[0:len(params) - 2]
            pairsofparams = cleanedparams.split('&')
            param = {}
            for i in range(len(pairsofparams)):
                splitparams = {}
                splitparams = pairsofparams[i].split('=')
                if (len(splitparams)) == 2:
                    param[splitparams[0]] = splitparams[1]
    except Exception as e:
        try:
            utils.core().error("get_params Error:" + str(e), xbmc.LOGERROR)
        except:
            pass
    return param


params = get_params()
url = utils.core().filterParams(params, "url")
name = utils.core().filterParams(params, "name")
mode = utils.core().filterParams(params, "mode")
iconimage = utils.core().filterParams(params, "iconimage")

###############################################################################################################
#                                                   MODOS                                                     #
###############################################################################################################
try:
    if mode == None:
        menu.menu()
    elif mode == 0:
        menu.menu().menu_root()
    elif mode == 1000:
        menu.menu().fechar()
    elif mode == 1:
        meganitube.menu()  # meganitube menu principal
    elif mode == 10:
        meganitube.getGeneros(url)  # generos de animes
    elif mode == 11:
        meganitube.getCategorias(url)  # categorias de animes
    elif mode == 12:
        meganitube.getEpisodios(url, iconimage)  # episodios de animes
    elif mode == 13:
        meganitube.doPlay(url, name, iconimage)  # player de animes
    elif mode == 14:
        meganitube.lastAnimes(url)  # ultimos lançados
    elif mode == 15:
        meganitube.doPesquisa()  # pesquisa
    elif mode == 2:
        animesorion.menu()  # animesorion menu principal
    elif mode == 20:
        animesorion.getGeneros(url)  # generos de animes legendados
    elif mode == 21:
        animesorion.getCategorias(url)  # categorias de animes
    elif mode == 22:
        animesorion.getEpisodios(url, iconimage)  # episodios de animes
    elif mode == 23:
        animesorion.doPlay(url, name, iconimage)  # player de animes
    elif mode == 24:
        animesorion.lastAnimes(url)  # ultimos lançados
    elif mode == 25:
        animesorion.doPesquisa()  # pesquisa
    elif mode == 3:
        vfohd.menu()  # vfohd menu principal
except Exception as e:
    try:
        utils.core().error("modes.py Error:" + str(e), xbmc.LOGERROR)
    except:
        pass
