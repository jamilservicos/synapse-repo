# -*- coding: utf-8 -*-
import xbmcaddon, os, sys
import utils

#mediaPath = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')


class menu:
    def __init__(self):
        self.addon_id = 'plugin.video.nymph'
        self.selfAddon = xbmcaddon.Addon(id=self.addon_id)
        self.addonfolder = self.selfAddon.getAddonInfo('path')
        self.mediaPath = self.addonfolder + '/resources/media'
        self.animesorionLogo = self.mediaPath + "/logos/animesorion.jpg"
        self.meganitubeLogo = self.mediaPath + "/logos/meganitube.png"
        self.vfohdLogo = self.mediaPath + "/logos/vfohd.png"
        self.open()

    def open(self):
        utils.core().addDir('none', 'Anitube', '-', 1, self.meganitubeLogo)
        utils.core().addDir('none', 'AnimesOrion', '-', 2, self.animesorionLogo)
        utils.core().addDir('none', 'FilmesHD', '-', 3, self.vfohdLogo)
        utils.core().addDir('none', 'Fechar', '-', 1000, '')
        self.endDirectory()

    def endDirectory(self, cacheToDisc=True):
        utils.core().directory(int(sys.argv[1]), cacheToDisc=cacheToDisc)

    def menu_root(self):
        utils.core().menuroot()

    def fechar(self):
        utils.core().fechar()
