# coding=utf-8
import urllib, urllib2, re, xbmcplugin, xbmcgui, xbmc, xbmcaddon, HTMLParser, random, sys
from xbmcgui import ListItem

from ..base import utils
import BeautifulSoup


class menu:
    def __init__(self):
        self.base = 'http://www.meganitube.com/'
        self.open()

    def open(self):
        utils.core().addDir('none', 'Ultimos', '-', '-', '-')
        utils.core().addDir('none', 'Gêneros', self.base, '20', '-')
        utils.core().addDir('none', 'Pesquisa', '-', '-', '-')
        self.endDirectory()

    def endDirectory(self, cacheToDisc=True):
        utils.core().directory(int(sys.argv[1]), cacheToDisc=cacheToDisc)