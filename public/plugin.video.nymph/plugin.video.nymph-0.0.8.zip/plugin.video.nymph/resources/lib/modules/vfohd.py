# coding=utf-8
import urllib, urllib2, re, xbmcplugin, xbmcgui, xbmc, xbmcaddon, HTMLParser, random, sys
from xbmcgui import ListItem

from ..base import utils
import BeautifulSoup

_base = 'http://www.assistirfilmeshd.org'
_addon_id = 'plugin.video.nymph'
_selfAddon = xbmcaddon.Addon(id=_addon_id)
_addonfolder = _selfAddon.getAddonInfo('path')
_mediaPath = _addonfolder + '/resources/media'
_vfohdLogo = _mediaPath + "/logos/vfohd.png"
_folderImage = _mediaPath + "/animegirl_1.jpg"
_searchImage = _mediaPath + "/animegirl_2.jpeg"

class menu:
    def __init__(self):
        self.open()

    def open(self):
        utils.core().addDir('none', 'Menu Principal', '-', 0, _folderImage)
        utils.core().addDir('none', 'Ultimos', _base, '-', _vfohdLogo)
        utils.core().addDir('none', 'Series', _base + '/categoria/series/', 31, _vfohdLogo)
        utils.core().addDir('none', 'Filmes',  _base + '/categoria/page/1', '-', _vfohdLogo)
        utils.core().addDir('none', 'Gêneros',  _base + '/categoria/', 30, _vfohdLogo)
        self.endDirectory()

    def endDirectory(self, cacheToDisc=True):
        utils.core().directory(int(sys.argv[1]), cacheToDisc=cacheToDisc)