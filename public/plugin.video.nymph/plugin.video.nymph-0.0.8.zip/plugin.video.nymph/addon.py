import xbmc
from resources.lib.base import utils, modes

try:
    modes
except Exception as e:
    try:
        utils.core().error("addon.py Error:" + str(e),xbmc.LOGERROR)
    except:
        pass